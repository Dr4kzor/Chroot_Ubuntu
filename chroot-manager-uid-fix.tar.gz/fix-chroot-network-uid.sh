#!/data/data/com.termux/files/usr/bin/bash
# Run in Termux after restoring a snapshot, before starting its desktop.
set -euo pipefail
PREFIX=/data/data/com.termux/files/usr
HERE=$(cd -- "$(dirname -- "$0")" && pwd)
TARGET=${1:-both}
MODE=${2:---dry-run}
CHROOT_UID_MIN=${CHROOT_UID_MIN:-60000}
CHROOT_UID_MAX=${CHROOT_UID_MAX:-60999}
[[ $CHROOT_UID_MIN =~ ^[0-9]+$ && $CHROOT_UID_MAX =~ ^[0-9]+$ ]] || { echo 'UID limits must be numeric.'; exit 2; }
case "$TARGET" in anland|termux-x11|both) ;; *) echo 'Target: anland, termux-x11, or both'; exit 2 ;; esac
case "$MODE" in --dry-run|--apply) ;; *) echo 'Mode: --dry-run or --apply'; exit 2 ;; esac
[[ -f "$HERE/fix-chroot-network-uid.py" ]] || { echo 'Missing Python helper beside this script.'; exit 1; }
exec 9>"$PREFIX/tmp/chroot-network-uid.lock"
flock -n 9 || { echo 'Another UID repair is running.'; exit 1; }
WORK=$(mktemp -d "$PREFIX/tmp/chroot-network-uid.XXXXXX")
trap 'rm -rf "$WORK"' EXIT
# Collect Android app identities before entering Ubuntu. Never modify them.
(unset LD_PRELOAD LD_LIBRARY_PATH; su -c "/system/bin/pm list packages -U --user 0 > '$WORK/packages'")
for NAME in termux-x11 anland; do
 [[ "$TARGET" == both || "$TARGET" == "$NAME" ]] || continue
 if [[ "$NAME" == anland ]]; then ROOT=/data/local/anland-ubuntu26; else ROOT=/data/local/ubuntu; fi
 # Private mounts are discarded on exit. No desktop or Android service is stopped.
 (unset LD_PRELOAD LD_LIBRARY_PATH; su -c "$PREFIX/bin/unshare --mount --propagation private /system/bin/sh -s") <<SYSTEM
set -eu
test -d '$ROOT/etc' || { echo '$NAME is not installed.'; exit 1; }
mkdir -p '$ROOT/proc'
mount -t proc proc '$ROOT/proc'
exec /system/bin/chroot '$ROOT' /usr/bin/env -i PATH=/usr/sbin:/usr/bin:/sbin:/bin HOME=/root /usr/bin/python3 - '$NAME' '$ROOT' '$MODE' '$CHROOT_UID_MIN' '$CHROOT_UID_MAX' "\$(/system/bin/cat '$WORK/packages')" < '$HERE/fix-chroot-network-uid.py'
SYSTEM
done
