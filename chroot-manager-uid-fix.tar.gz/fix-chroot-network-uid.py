"""Executed as root inside Ubuntu by fix-chroot-network-uid.sh; no downloads."""
import base64
import json
import os
import pwd
import re
import socket
import stat
import struct
import subprocess
import sys
from pathlib import Path

name, host_root, mode, low, high, packages = sys.argv[1:]
low, high = int(low), int(high)
if not 5000 <= low <= high < 90000 or high - low > 10000:
    sys.exit('Choose a bounded candidate range between 5000 and 89999.')
apply = mode == '--apply'
state = Path('/var/lib/chroot-network-uid')
journal = state / 'migration.json'

def save(data):
    state.mkdir(mode=0o700, parents=True, exist_ok=True)
    temporary = state / 'migration.json.tmp'
    with temporary.open('w') as stream:
        os.chmod(temporary, 0o600)
        json.dump(data, stream)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, journal)

record = json.loads(journal.read_text()) if journal.exists() else None
if record and record['root'] != host_root:
    sys.exit('Migration journal belongs to a different rootfs.')
if record and record['phase'] != 'complete':
    account = pwd.getpwnam(record['user'])
else:
    if name == 'anland':
        account = pwd.getpwuid(int(Path('/etc/anland-user.uid').read_text().strip()))
    else:
        candidates = [p for p in pwd.getpwall() if 1000 <= p.pw_uid < 90000
                      and p.pw_dir.startswith('/home/')
                      and not p.pw_shell.endswith(('nologin', 'false'))]
        account = next((p for p in candidates if p.pw_name == 'user'), None)
        if account is None:
            if len(candidates) != 1:
                sys.exit('Cannot identify the X11 desktop account unambiguously.')
            account = candidates[0]
groups = os.getgrouplist(account.pw_name, account.pw_gid)

def probe(uid):
    # A root-owned local listener makes the test independent of FTP, DNS and Wi-Fi.
    listener = socket.socket()
    listener.bind(('127.0.0.1', 0))
    listener.listen(1)
    pid = os.fork()
    if pid == 0:
        try:
            address = listener.getsockname()
            listener.close()
            os.setgroups(groups)
            os.setgid(account.pw_gid)
            os.setuid(uid)
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM):
                pass
            with socket.socket() as client:
                client.settimeout(3)
                client.connect(address)
            os._exit(0)
        except OSError:
            os._exit(1)
    _, status = os.waitpid(pid, 0)
    listener.close()
    return os.waitstatus_to_exitcode(status) == 0

if not record or record['phase'] == 'complete':
    if probe(account.pw_uid):
        print(f'{name}: {account.pw_name} UID {account.pw_uid} already passes TCP/UDP checks.')
        sys.exit(0)

# Refuse migration while any process is rooted in this chroot, except ourselves.
busy = []
used = {p.pw_uid for p in pwd.getpwall()}
used.update(map(int, re.findall(r'uid:(\d+)', packages)))
for process in Path('/proc').iterdir():
    if not process.name.isdigit():
        continue
    try:
        status = (process / 'status').read_text()
        used.update(map(int, re.search(r'^Uid:\s+(.+)$', status, re.M).group(1).split()))
        root = os.readlink(process / 'root').rstrip('/')
        if (root == host_root or root.startswith(host_root + '/')) and int(process.name) != os.getpid():
            busy.append(process.name)
    except (OSError, AttributeError):
        continue
if busy:
    sys.exit('Stop the chroot first; active process IDs: ' + ', '.join(busy))

if record and record['phase'] != 'complete':
    old, new = record['old_uid'], record['new_uid']
    if account.pw_uid not in (old, new) or not probe(new):
        sys.exit('Pending migration conflicts with account/network state; inspect migration.json.')
else:
    # Avoid app, SDK sandbox and isolated-app UID ranges even with a custom range.
    new = next((uid for uid in range(low, high + 1)
                if uid not in used and not 10000 <= uid < 30000 and probe(uid)), None)
    if new is None:
        sys.exit('No working unused UID found in the configured range.')
    old = account.pw_uid
    record = {'user': account.pw_name, 'old_uid': old, 'new_uid': new,
              'phase': 'prepared', 'root': host_root}
print(f'{name}: {account.pw_name}: UID {old} -> {new}; primary GID {account.pw_gid} stays unchanged.')
if not apply:
    print('Dry run: no accounts or files changed. Rerun with --apply after stopping the desktop.')
    sys.exit(0)

# Skip all child mounts, including bind mounts on the same filesystem.
def unescape(value):
    return re.sub(r'\\([0-7]{3})', lambda m: chr(int(m[1], 8)), value)

mounts = set()
for line in Path('/proc/self/mountinfo').read_text().splitlines():
    mount = unescape(line.split()[4])
    if mount.startswith(host_root + '/'):
        mounts.add(mount[len(host_root):])
    elif mount.startswith('/') and mount != '/' and not mount.startswith('/data/'):
        mounts.add(mount)
excluded = mounts | {'/proc', '/sys', '/dev', '/sdcard', '/storage', '/run', '/tmp', str(state)}
if any(m == account.pw_dir or m.startswith(account.pw_dir + '/') for m in mounts):
    sys.exit('Unmount paths in the desktop home before migration; usermod must not reach external files.')

if not journal.exists() or record['phase'] == 'prepared':
    state.mkdir(mode=0o700, parents=True, exist_ok=True)
    for filename in ('passwd', 'shadow', 'group', 'gshadow', 'anland-user.uid'):
        source = Path('/etc') / filename
        backup = state / (filename + '.before')
        if source.exists() and not backup.exists():
            import shutil
            shutil.copy2(source, backup)
            os.chmod(backup, 0o600)
    save(record)

# Capture ownership, modes, capabilities and numeric POSIX ACL entries before usermod.
manifest = state / 'files.jsonl'
if record['phase'] == 'prepared':
    with manifest.open('w') as output:
        os.chmod(manifest, 0o600)
        for directory, subdirs, files in os.walk('/', followlinks=False):
            subdirs[:] = [d for d in subdirs if os.path.join(directory, d) not in excluded]
            links = [d for d in subdirs if os.path.islink(os.path.join(directory, d))]
            for path in [directory] + [os.path.join(directory, f) for f in files + links]:
                info = os.lstat(path)
                attrs = {}
                if not stat.S_ISLNK(info.st_mode):
                    for key in os.listxattr(path, follow_symlinks=False):
                        if key in ('system.posix_acl_access', 'system.posix_acl_default', 'security.capability'):
                            attrs[key] = base64.b64encode(os.getxattr(path, key, follow_symlinks=False)).decode()
                acl_match = any(any(tag == 2 and qualifier == old
                                    for tag, perm, qualifier in struct.iter_unpack('<HHI', base64.b64decode(v)[4:]))
                                for k, v in attrs.items() if k.startswith('system.posix_acl'))
                if info.st_uid == old or acl_match:
                    output.write(json.dumps({'path': path, 'uid': info.st_uid, 'gid': info.st_gid,
                                             'mode': stat.S_IMODE(info.st_mode), 'attrs': attrs}) + '\n')
        output.flush()
        os.fsync(output.fileno())
    record['phase'] = 'manifest-ready'
    save(record)

if pwd.getpwnam(account.pw_name).pw_uid == old:
    subprocess.run(['usermod', '-u', str(new), account.pw_name], check=True)
record['phase'] = 'ownership'
save(record)
with manifest.open() as entries:
    for line in entries:
        entry = json.loads(line)
        path = entry['path']
        if not os.path.lexists(path):
            continue
        if entry['uid'] == old:
            os.chown(path, new, entry['gid'], follow_symlinks=False)
        if not os.path.islink(path):
            os.chmod(path, entry['mode'])
            for key, encoded in entry['attrs'].items():
                value = base64.b64decode(encoded)
                if key.startswith('system.posix_acl'):
                    value = value[:4] + b''.join(struct.pack('<HHI', tag, perm, new if tag == 2 and qualifier == old else qualifier)
                                                for tag, perm, qualifier in struct.iter_unpack('<HHI', value[4:]))
                os.setxattr(path, key, value, follow_symlinks=False)
if name == 'anland':
    Path('/etc/anland-user.uid').write_text(str(new) + '\n')
account = pwd.getpwnam(account.pw_name)
if not probe(account.pw_uid):
    sys.exit('Post-migration socket check failed; journal retained for inspection.')
record['phase'] = 'complete'
save(record)
print(f'{name}: repair complete; TCP/UDP checks passed. Recovery records: {state}')
