Upload these seven existing scripts to the root of the Chroot_Ubuntu repository:
install-chroot-termux-x11.sh
restore-chroot-termux-x11.sh
backup-chroot-termux-x11.sh
uninstall-chroot-termux-x11.sh
restore-chroot-anland.sh
backup-chroot-anland.sh
uninstall-chroot-anland.sh

Upload these release assets using these exact filenames:
ubuntu-termux-x11-backup.tar.gz
ubuntu-anland-backup.tar.gz

Install, save and load use the new Termux-X11 archive filename.
The installer loaders import the five numbered saved scripts and matching icons,
preserve their contents and remove the desktop's obsolete shortcut names.
Each saved snapshot contains only its own five numbered shortcuts and icons.
The self-contained Widget shortcuts do not call these manager helper scripts.
The seven files update chroot_manager's installation, backup and uninstall paths.
No desktop or first-run script was executed while preparing the snapshots.
